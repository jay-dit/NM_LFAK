from setuptools import setup

setup(name='NM_LFAK',
      version='0.0',
      description='Numerical methods',
      packages=['NM_LFAK'],
      author_email='vovalagutov1111@yandex.ru',
      zip_safe=False)