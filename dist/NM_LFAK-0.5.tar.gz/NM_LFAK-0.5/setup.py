from setuptools import setup, find_packages

setup(name='NM_LFAK',
      version='0.5',
      description='Numerical methods',
      packages=find_packages(),
      author_email='vovalagutov1111@yandex.ru',
      zip_safe=False,
      )