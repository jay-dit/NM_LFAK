# NM_LFAK

Импортировать вот так - from NM_LFAK.interp1d import *

Все задачи упакованы в отдельные модули библиотеки 

Список модулей 
<ul>
  <li>annealing</li>
  <li>diffint</li>
  <li>fourwave</li>
  <li>interp1d</li>
  <li>matrix</li>
  <li>odu</li>
</ul>