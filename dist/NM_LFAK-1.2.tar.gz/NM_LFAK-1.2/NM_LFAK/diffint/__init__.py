''' documentation for diffint'''

from .main import *