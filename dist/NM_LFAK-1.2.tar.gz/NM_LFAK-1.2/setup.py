from setuptools import setup, find_packages


setup(name='NM_LFAK',
      version='1.2',
      description='Numerical methods',
      packages=find_packages(),
      author_email='vovalagutov1111@yandex.ru',
      install_requires = ['numpy'],
      zip_safe=False,
      )
